﻿using MelonLoader;

namespace $safeprojectname$
{
    public static class BuildInfo
    {
        public const string Name = "$safeprojectname$";
        public const string Author = "REPLACE_ME";
        public const string Company = null;
        public const string Version = "1.0.0";
        public const string DownloadLink = null;
    }

    public class $safeprojectname$ : MelonMod
    {
        public override void OnApplicationStart()
        {
            MelonLogger.Msg("OnApplicationStart");
        }

        public override void OnSceneWasInitialized(int buildindex, string sceneName)
        {
            MelonLogger.Msg("OnSceneWasInitialized: " + buildindex.ToString() + " | " + sceneName);
        }

        public override void OnUpdate()
        {
            MelonLogger.Msg("OnUpdate");
        }
    }
}
